#include<stdio.h>
#include<string.h>
#include <arpa/nameser.h>


void consulta_LOC(unsigned char *reader);